﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QueryAPI.DTO
{
    public class ContentMedicamentoDTO
    {
        public int orderm { get; set; }
        public produtoDTO produto { get; set; }
        public EmpresaDTO empresa { get; set; }
        public processoDTO processo { get; set; }
    }
}
