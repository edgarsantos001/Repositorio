﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QueryAPI.DTO
{
  public class ClasseDTO
    {
        public string classe { get; set; }
    }
}
