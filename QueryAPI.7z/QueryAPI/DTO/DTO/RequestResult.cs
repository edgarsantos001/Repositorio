﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QueryAPI.DTO
{
    public class RequestResult
    {
        public string Status { get; set; }
    }
}
