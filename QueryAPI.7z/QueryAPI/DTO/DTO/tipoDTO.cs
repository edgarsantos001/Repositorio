﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QueryAPI.DTO
{
    public class tipoDTO
    {
        public int codigo { get; set; }
        public string descricao { get; set; }
    }
}
