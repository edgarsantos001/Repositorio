﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QueryAPI.Data
{
    public class Repository
    {

    }
}
