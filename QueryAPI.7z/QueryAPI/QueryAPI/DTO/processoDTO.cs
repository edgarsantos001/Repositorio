﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QueryAPI.DTO
{
   public class processoDTO
    {
        public string numero { get; set; }
        public int situacao { get; set; }
        public string numeroProcessoFormatado { get; set; }
    }

}
