﻿namespace QueryAPI.DTO
{
    public class MensagemDTO
    {
        public string situacao { get; set; }
        public string resolucao { get; set; }
        public string motivo { get; set; }
        public bool negativo { get; set; }
    }
}