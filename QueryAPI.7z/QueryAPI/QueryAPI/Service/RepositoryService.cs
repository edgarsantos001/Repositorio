﻿using QueryAPI.Interface;
using System;
using System.Collections.Generic;
using System.Text;

namespace QueryAPI.Service
{
    public class RepositoryService : IRepository
    {

    }
}
