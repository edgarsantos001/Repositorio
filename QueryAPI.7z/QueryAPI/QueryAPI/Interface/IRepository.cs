﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QueryAPI.Interface
{
    public interface IRepository
    {
    }
}
