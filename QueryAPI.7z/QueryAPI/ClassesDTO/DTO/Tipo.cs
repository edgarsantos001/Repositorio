﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassesDTO.DTO
{
    public class Tipo
    {
        public int codigo { get; set; }
        public string descricao { get; set; }
    }
}
