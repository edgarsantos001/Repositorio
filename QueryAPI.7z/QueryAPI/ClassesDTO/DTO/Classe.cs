﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassesDTO.DTO
{
  public class Classe
    {
        public string classe { get; set; }
    }
}
