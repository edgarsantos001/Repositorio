﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassesDTO.DTO.MedDTO
{
    public class FabricanteDTO
    {
        public string RAZAO_SOCIAL { get; set; }
        public string CNPJ { get; set; }
        public string PAIS { get; set; }
        public string UF { get; set; }
        public string CIDADE { get; set; }
        public string ENDERECO { get; set; }
    }
}
