﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassesDTO.DTO
{
    public class RequestResult
    {
        public string Status { get; set; }
    }
}
